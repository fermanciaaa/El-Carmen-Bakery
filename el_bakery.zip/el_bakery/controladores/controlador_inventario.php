<?php
/**
 * Controlador de Inventario — MVC (capa Controlador)
 *
 * Operaciones (campo 'operacion' en POST):
 *   1 → Ajustar stock manualmente
 *   2 → Recargar HTML de la tabla
 *   3 → Cargar datos de una fila para edición
 */

session_start();

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'msg' => 'Sesión expirada.']);
    exit;
}

require_once '../modelos/conexion.php';
require_once '../modelos/inventario.php';

$modelo = new Inventario();

if (isset($_REQUEST['operacion'])) {

    switch ((int) $_REQUEST['operacion']) {

        // ── 1: Ajustar stock ───────────────────────────────────────────────
        case 1:
            $id_inv       = (int) ($_POST['id_inventario'] ?? 0);
            $nuevo_stock  = (int) ($_POST['stock_actual']  ?? -1);
            $stock_minimo = (int) ($_POST['stock_minimo']  ?? 5);

            if ($id_inv === 0 || $nuevo_stock < 0) {
                echo "Datos inválidos para ajuste de stock.";
                break;
            }

            $rs = $modelo->ajustar_stock($id_inv, $nuevo_stock, $stock_minimo);
            echo ($rs === true) ? "1" : $rs;
            break;

        // ── 2: Recargar tabla ──────────────────────────────────────────────
        case 2:
            echo $modelo->vista_tabla();
            break;

        // ── 3: Cargar fila para edición ────────────────────────────────────
        case 3:
            $id_inv = (int) ($_POST['id_inventario'] ?? 0);
            $fila   = $modelo->obtener_por_id($id_inv);
            echo $fila ? json_encode($fila) : json_encode(['error' => 'Registro no encontrado.']);
            break;

        default:
            echo "Operación no reconocida.";
            break;
    }
}
