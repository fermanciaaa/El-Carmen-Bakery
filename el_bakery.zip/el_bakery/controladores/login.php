<?php
/**
 * Controlador de Login — MVC (capa Controlador)
 * Responsabilidad: recibir la petición AJAX del formulario de login,
 * invocar el modelo y devolver JSON al cliente.
 */

session_start();

// Incluir las clases necesarias (modelo depende de conexión)
require_once '../modelos/conexion.php';
require_once '../modelos/login.php';

// Solo procesamos peticiones POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $correo   = trim($_POST['correo']   ?? '');
    $password = trim($_POST['password'] ?? '');

    // Validación básica en servidor (el cliente ya valida con HTML5 required)
    if (empty($correo) || empty($password)) {
        echo json_encode(['success' => false, 'msg' => 'Complete todos los campos.']);
        exit;
    }

    $login    = new Login();
    $usuario  = $login->verificar($correo, $password);

    if ($usuario) {
        // Guardar datos de sesión (solo lo necesario, nunca la contraseña)
        $_SESSION['id_usuario'] = $usuario['id_usuario'];
        $_SESSION['nombre']     = $usuario['nombre'] . ' ' . $usuario['apellido'];
        $_SESSION['correo']     = $usuario['correo'];
        $_SESSION['rol']        = $usuario['rol'];

        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'msg' => 'Correo o contraseña incorrectos.']);
    }

} else {
    // Alguien intentó acceder directamente al controlador vía GET
    header('Location: ../index.php');
    exit;
}
