<?php
/**
 * Controlador de Logout — MVC (capa Controlador)
 * Responsabilidad: destruir la sesión activa y redirigir al login.
 */

session_start();
session_unset();    // limpiar todas las variables de sesión
session_destroy();  // destruir el archivo de sesión en el servidor

// Redirigir al índice (página de login)
header('Location: ../index.php');
exit;
