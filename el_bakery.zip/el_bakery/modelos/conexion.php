<?php
/**
 * Clase Conexion
 * Responsabilidad: proveer una instancia PDO configurada para el_bakery.
 * Todas las clases del modelo extienden de esta clase (herencia MVC - capa Modelo).
 */
class Conexion
{
    /**
     * Retorna una conexión PDO lista para usar.
     * Se lanza una excepción si la conexión falla, evitando continuar con datos nulos.
     */
    public function conx_pdo()
    {
        $conexion = null;
        try {
            $conexion = new PDO(
                'mysql:host=localhost;dbname=el_bakery;port=3306;charset=utf8mb4',
                'root',   // ← cambiar según el entorno
                ''        // ← cambiar según el entorno
            );
            // Activar modo excepción para capturar errores SQL fácilmente
            $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $ex) {
            // En producción no mostrar detalles; aquí los mostramos para desarrollo
            echo "Error de conexión: " . $ex->getMessage();
            exit;
        }
        return $conexion;
    }
}
