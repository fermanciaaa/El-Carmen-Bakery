<?php
/**
 * Clase Inventario — Modelo
 * Responsabilidad: consultar y ajustar manualmente el stock en la tabla `inventario`.
 * Nota: el incremento automático de stock al registrar compras lo maneja el trigger
 *       `trg_stock_entrada` en la BD. Este modelo expone el ajuste manual y la consulta.
 */
class Inventario extends Conexion
{
    // ─────────────────────────────────────────────
    //  LECTURA
    // ─────────────────────────────────────────────

    /**
     * Retorna el inventario completo con nombre del producto y alertas de stock mínimo.
     */
    public function obtener_todos()
    {
        // La columna 'alerta' vale 1 si el stock está en o bajo el mínimo, 0 si no
        $sql = "SELECT i.id_inventario, p.nombre_producto,
                       i.stock_actual, i.stock_minimo,
                       p.id_producto_catalogo,
                       IF(i.stock_actual <= i.stock_minimo, 1, 0) AS alerta
                  FROM inventario i
                  JOIN producto_catalogo p ON p.id_producto_catalogo = i.id_producto_catalogo
                 ORDER BY alerta DESC, p.nombre_producto ASC";
        $conx = parent::conx_pdo();
        $stm  = $conx->prepare($sql);
        $stm->execute();
        return $stm->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Retorna una fila de inventario por su ID (para edición de stock_minimo).
     */
    public function obtener_por_id($id_inventario)
    {
        $sql = "SELECT i.id_inventario, i.stock_actual, i.stock_minimo,
                       i.id_producto_catalogo, p.nombre_producto
                  FROM inventario i
                  JOIN producto_catalogo p ON p.id_producto_catalogo = i.id_producto_catalogo
                 WHERE i.id_inventario = :id";
        $conx = parent::conx_pdo();
        $stm  = $conx->prepare($sql);
        $stm->bindParam(':id', $id_inventario, PDO::PARAM_INT);
        $stm->execute();
        return $stm->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Cuenta cuántos productos están en nivel de alerta (stock ≤ mínimo).
     * Se usa para mostrar badge en el menú de navegación.
     */
    public function contar_alertas()
    {
        $sql  = "SELECT COUNT(*) FROM inventario WHERE stock_actual <= stock_minimo";
        $conx = parent::conx_pdo();
        $stm  = $conx->prepare($sql);
        $stm->execute();
        return (int) $stm->fetchColumn();
    }

    // ─────────────────────────────────────────────
    //  ESCRITURA
    // ─────────────────────────────────────────────

    /**
     * Ajusta manualmente el stock_actual de un producto.
     * Útil para correcciones por merma, pérdida o conteo físico.
     *
     * @param int $id_inventario
     * @param int $nuevo_stock    Nuevo valor absoluto del stock
     * @param int $stock_minimo   Umbral de alerta de reposición
     * @return true|string
     */
    public function ajustar_stock($id_inventario, $nuevo_stock, $stock_minimo)
    {
        try {
            // Validar que el stock no sea negativo (la BD también lo controla con CHECK)
            if ($nuevo_stock < 0) {
                return "El stock no puede ser negativo.";
            }
            $sql = "UPDATE inventario
                       SET stock_actual  = :stock,
                           stock_minimo  = :minimo
                     WHERE id_inventario = :id";
            $conx = parent::conx_pdo();
            $stm  = $conx->prepare($sql);
            $stm->bindParam(':stock',  $nuevo_stock,  PDO::PARAM_INT);
            $stm->bindParam(':minimo', $stock_minimo, PDO::PARAM_INT);
            $stm->bindParam(':id',     $id_inventario, PDO::PARAM_INT);
            $stm->execute();
            return true;
        } catch (PDOException $e) {
            return "Error al ajustar stock: " . $e->getMessage();
        }
    }

    // ─────────────────────────────────────────────
    //  GENERACIÓN DE HTML
    // ─────────────────────────────────────────────

    /**
     * Genera las filas <tr> de la tabla de inventario.
     * Resalta en amarillo/rojo las filas con alerta de stock bajo.
     */
    public function vista_tabla()
    {
        $filas = $this->obtener_todos();
        $html  = '';
        $n     = 0;

        foreach ($filas as $f) {
            $n++;
            $alerta  = (bool) $f['alerta'];
            // Clase de fila: warning si está en alerta, normal si no
            $tr_class = $alerta ? 'class="table-warning"' : '';

            $badge_stock = $alerta
                ? '<span class="badge bg-danger">' . $f['stock_actual'] . '</span>'
                : '<span class="badge bg-success">' . $f['stock_actual'] . '</span>';

            $html .= '<tr ' . $tr_class . '>';
            $html .= '<td>' . $n . '</td>';
            $html .= '<td>' . htmlspecialchars($f['nombre_producto']) . '</td>';
            $html .= '<td class="text-center">' . $badge_stock . '</td>';
            $html .= '<td class="text-center">' . $f['stock_minimo'] . '</td>';
            $html .= '<td class="text-center">';
            // Ícono de alerta visible solo cuando el stock está bajo
            if ($alerta) {
                $html .= '<i class="bi bi-exclamation-triangle-fill text-warning" title="Stock bajo"></i> ';
            }
            $html .= '<button class="btn btn-sm btn-warning btn-ajustar"
                              data-id="'     . $f['id_inventario']        . '"
                              data-stock="'  . $f['stock_actual']         . '"
                              data-minimo="' . $f['stock_minimo']         . '"
                              data-nombre="' . htmlspecialchars($f['nombre_producto']) . '"
                              title="Ajustar stock">
                          <i class="bi bi-pencil-fill"></i>
                      </button>';
            $html .= '</td>';
            $html .= '</tr>';
        }
        return $html;
    }
}
