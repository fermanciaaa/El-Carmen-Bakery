<?php
/**
 * Vista: Panel Principal — MVC (capa Vista)
 * Punto de entrada a todos los módulos después del login.
 * Muestra el módulo activo según el parámetro GET 'modulo'.
 */

session_start();

// Verificar sesión activa; si no hay, redirigir al login
if (!isset($_SESSION['id_usuario'])) {
    header('Location: ../index.php');
    exit;
}

// Incluir modelos necesarios para las vistas iniciales
require_once '../modelos/conexion.php';
require_once '../modelos/usuarios.php';
require_once '../modelos/productos.php';
require_once '../modelos/inventario.php';

$data_usuarios  = new Usuarios();
$data_productos = new Productos();
$data_inventario = new Inventario();

// Módulo activo (por defecto: usuarios)
$modulo = $_GET['modulo'] ?? 'usuarios';

// Cantidad de alertas de inventario para el badge del menú
$alertas_inv = $data_inventario->contar_alertas();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>El Bakery — Panel</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <!-- DataTables -->
    <link href="https://cdn.datatables.net/2.0.3/css/dataTables.dataTables.min.css" rel="stylesheet">

    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>

<!-- ══════════════════════════════════════════════════════════════
     NAVBAR
════════════════════════════════════════════════════════════════ -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid px-4">

        <a class="navbar-brand fw-bold text-warning" href="panel.php">
            <i class="bi bi-shop-window me-1"></i> El Bakery
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navMain">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">

                <!-- Módulo Usuarios -->
                <li class="nav-item">
                    <a class="nav-link <?= $modulo === 'usuarios'   ? 'active' : '' ?>"
                       href="panel.php?modulo=usuarios">
                        <i class="bi bi-people-fill me-1"></i> Usuarios
                    </a>
                </li>

                <!-- Módulo Productos -->
                <li class="nav-item">
                    <a class="nav-link <?= $modulo === 'productos'  ? 'active' : '' ?>"
                       href="panel.php?modulo=productos">
                        <i class="bi bi-box-seam-fill me-1"></i> Productos
                    </a>
                </li>

                <!-- Módulo Inventario (con badge de alertas) -->
                <li class="nav-item">
                    <a class="nav-link <?= $modulo === 'inventario' ? 'active' : '' ?>"
                       href="panel.php?modulo=inventario">
                        <i class="bi bi-clipboard2-data-fill me-1"></i> Inventario
                        <?php if ($alertas_inv > 0): ?>
                            <span class="badge bg-danger ms-1"><?= $alertas_inv ?></span>
                        <?php endif; ?>
                    </a>
                </li>

                <!-- Módulos esqueleto (no funcionales aún) -->
                <li class="nav-item">
                    <a class="nav-link text-secondary" href="#" title="Módulo en desarrollo">
                        <i class="bi bi-cart3 me-1"></i> Ventas
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-secondary" href="#" title="Módulo en desarrollo">
                        <i class="bi bi-truck me-1"></i> Compras
                    </a>
                </li>

            </ul>

            <!-- Info del usuario logueado + botón de salir -->
            <ul class="navbar-nav ms-auto">
                <li class="nav-item d-flex align-items-center me-3">
                    <i class="bi bi-person-circle me-1 text-warning"></i>
                    <span class="text-light small">
                        <?= htmlspecialchars($_SESSION['nombre']) ?>
                        <span class="badge bg-secondary ms-1"><?= htmlspecialchars($_SESSION['rol']) ?></span>
                    </span>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-danger" href="../controladores/logout.php"
                       onclick="return confirm('¿Deseas cerrar sesión?')">
                        <i class="bi bi-box-arrow-right me-1"></i> Salir
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- ══════════════════════════════════════════════════════════════
     CONTENIDO PRINCIPAL
════════════════════════════════════════════════════════════════ -->
<main class="container-fluid px-4 pt-panel">

    <?php
    // Cargar la vista del módulo activo (patrón de inclusión condicional)
    switch ($modulo) {
        case 'usuarios':
            include 'modulos/usuarios.php';
            break;
        case 'productos':
            include 'modulos/productos.php';
            break;
        case 'inventario':
            include 'modulos/inventario.php';
            break;
        default:
            include 'modulos/usuarios.php';
            break;
    }
    ?>

</main>

<!-- ══════════════════════════════════════════════════════════════
     FOOTER
════════════════════════════════════════════════════════════════ -->
<footer class="footer text-center py-3 text-muted small border-top mt-4">
    © <span id="anio"></span> El Bakery — Sistema de Punto de Venta
</footer>

<!-- ══════════════════════════════════════════════════════════════
     SCRIPTS GLOBALES
════════════════════════════════════════════════════════════════ -->
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="https://cdn.datatables.net/2.0.3/js/dataTables.min.js"></script>
<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- Script del módulo activo -->
<?php if ($modulo === 'usuarios'):   ?><script src="../js/usuarios.js"></script><?php endif; ?>
<?php if ($modulo === 'productos'):  ?><script src="../js/productos.js"></script><?php endif; ?>
<?php if ($modulo === 'inventario'): ?><script src="../js/inventario.js"></script><?php endif; ?>

<script>
    document.getElementById('anio').textContent = new Date().getFullYear();
</script>
</body>
</html>
