<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>El Bakery — Iniciar Sesión</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <link rel="stylesheet" href="css/styles.css">
</head>
<body class="login-bg d-flex justify-content-center align-items-center min-vh-100">

    <div class="login-card card shadow-lg p-4" style="width: 100%; max-width: 420px;">

        <!-- Logo / Encabezado -->
        <div class="text-center mb-4">
            <i class="bi bi-shop-window fs-1 text-warning"></i>
            <h2 class="mt-2 fw-bold">El Bakery</h2>
            <p class="text-muted small">Sistema de Punto de Venta</p>
        </div>

        <!-- Formulario de login -->
        <form id="formLogin" novalidate>

            <div class="mb-3">
                <label for="correo" class="form-label">Correo electrónico</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                    <input type="email" id="correo" name="correo"
                           class="form-control" placeholder="usuario@elbakery.com"
                           autocomplete="off" required>
                </div>
            </div>

            <div class="mb-4">
                <label for="password" class="form-label">Contraseña</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" id="password" name="password"
                           class="form-control" placeholder="••••••••" required>
                    <!-- Botón para mostrar/ocultar contraseña -->
                    <button type="button" class="btn btn-outline-secondary" id="togglePass">
                        <i class="bi bi-eye" id="iconoOjo"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn btn-warning w-100 fw-semibold">
                <i class="bi bi-box-arrow-in-right me-1"></i> Ingresar
            </button>
        </form>
    </div>

<script>
// ── Mostrar / ocultar contraseña ────────────────────────────────────────────
$('#togglePass').on('click', function () {
    const campo = $('#password');
    const icono = $('#iconoOjo');
    if (campo.attr('type') === 'password') {
        campo.attr('type', 'text');
        icono.removeClass('bi-eye').addClass('bi-eye-slash');
    } else {
        campo.attr('type', 'password');
        icono.removeClass('bi-eye-slash').addClass('bi-eye');
    }
});

// ── Envío del formulario por AJAX ───────────────────────────────────────────
$('#formLogin').on('submit', function (e) {
    e.preventDefault();

    const correo   = $('#correo').val().trim();
    const password = $('#password').val().trim();

    if (!correo || !password) {
        Swal.fire({ icon: 'warning', title: 'Campos vacíos', text: 'Complete todos los campos.' });
        return;
    }

    $.ajax({
        url:      'controladores/login.php',
        method:   'POST',
        dataType: 'json',
        data:     { correo, password },
        success: function (res) {
            if (res.success) {
                Swal.fire({
                    icon: 'success',
                    title: '¡Bienvenido!',
                    text:  'Acceso correcto.',
                    timer: 1400,
                    showConfirmButton: false
                }).then(() => {
                    window.location.href = 'vistas/panel.php';
                });
            } else {
                Swal.fire({ icon: 'error', title: 'Acceso denegado', text: res.msg, confirmButtonColor: '#dc3545' });
            }
        },
        error: function () {
            Swal.fire({ icon: 'error', title: 'Error', text: 'No se pudo conectar con el servidor.' });
        }
    });
});
</script>
</body>
</html>
