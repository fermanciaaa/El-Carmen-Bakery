# El Bakery — Sistema de Punto de Venta
## Guía de instalación y configuración

---

### Requisitos
- PHP 8.0 o superior
- MySQL 8.0 o superior
- Servidor web: Apache (XAMPP/WAMP) o equivalente

---

### Pasos de instalación

**1. Base de datos**
- Ejecutar primero `bakery.txt` (esquema principal + triggers de stock).
- Ejecutar después `bakery_auditoria_triggers.txt` (tablas y triggers de auditoría).
- Ambos scripts crean y usan la base de datos `el_bakery`.

**2. Usuario administrador inicial**
El script de BD crea un usuario de prueba con hash de marcador. Para
poder ingresar al sistema necesitas actualizar la contraseña con un
hash bcrypt real. Ejecuta esto en MySQL:

```sql
UPDATE usuarios
   SET contrasenia = '$2y$12$REEMPLAZA_CON_HASH_REAL'
 WHERE correo = 'admin@elbakery.com';
```

Para generar el hash en PHP:
```php
<?php echo password_hash('tu_contraseña', PASSWORD_BCRYPT, ['cost' => 12]); ?>
```

O usa el archivo `test.php` incluido en el proyecto.

**3. Conexión a la BD**
Editar `modelos/conexion.php` y ajustar:
```php
$conexion = new PDO(
    'mysql:host=localhost;dbname=el_bakery;port=3306;charset=utf8mb4',
    'root',   // ← tu usuario MySQL
    ''        // ← tu contraseña MySQL
);
```

**4. Colocar el proyecto**
- Copiar la carpeta `el_bakery` dentro de `htdocs` (XAMPP) o `www` (WAMP).
- Acceder desde el navegador: `http://localhost/el_bakery/`

---

### Estructura del proyecto (MVC)

```
el_bakery/
│
├── index.php                    ← Página de login (Vista pública)
│
├── modelos/                     ← Capa Modelo: acceso a BD
│   ├── conexion.php             ← Clase base PDO
│   ├── login.php                ← Verificación de credenciales
│   ├── usuarios.php             ← CRUD de usuarios
│   ├── productos.php            ← CRUD de catálogo de productos
│   └── inventario.php          ← Consulta y ajuste de stock
│
├── controladores/               ← Capa Controlador: lógica de negocio
│   ├── login.php                ← Procesa autenticación (AJAX)
│   ├── logout.php               ← Destruye sesión
│   ├── controlador_usuarios.php ← CRUD usuarios (AJAX)
│   ├── controlador_productos.php← CRUD productos (AJAX)
│   └── controlador_inventario.php← Ajuste de stock (AJAX)
│
├── vistas/                      ← Capa Vista: HTML generado
│   ├── panel.php                ← Panel principal (con navbar)
│   └── modulos/                 ← Vistas parciales por módulo
│       ├── usuarios.php
│       ├── productos.php
│       └── inventario.php
│
├── js/                          ← JavaScript por módulo
│   ├── usuarios.js
│   ├── productos.js
│   └── inventario.js
│
└── css/
    └── styles.css               ← Estilos globales
```

---

### Módulos funcionales
| Módulo      | Listar | Agregar | Editar | Activar/Desactivar |
|-------------|:------:|:-------:|:------:|:------------------:|
| Usuarios    | ✅     | ✅      | ✅     | ✅                 |
| Productos   | ✅     | ✅      | ✅     | ✅                 |
| Inventario  | ✅     | —*      | ✅     | —                  |
| Ventas      | 🔲     | 🔲      | 🔲     | 🔲                 |
| Compras     | 🔲     | 🔲      | 🔲     | 🔲                 |

*El stock del inventario se crea automáticamente cuando se registra
 una compra (trigger `trg_stock_entrada` en la BD). El módulo permite
 ajuste manual para correcciones por merma o conteo físico.

---

### Credenciales de prueba
- **Correo:** `admin@elbakery.com`
- **Contraseña:** la que hayas generado en el paso 2

---

### Variable de sesión para auditoría
Los triggers de auditoría leen `@usuario_sesion`. Si quieres activar
la auditoría completa, agrega esta línea en `modelos/conexion.php`
justo después de crear la conexión PDO:

```php
if (isset($_SESSION['id_usuario'])) {
    $conexion->exec("SET @usuario_sesion = " . (int)$_SESSION['id_usuario']);
}
```

---

### Tecnologías utilizadas
- **Backend:** PHP 8 + PDO (MySQL)
- **Frontend:** Bootstrap 5.3, Bootstrap Icons, jQuery 3.7
- **Tablas:** DataTables 2.0 (con i18n en español)
- **Alertas:** SweetAlert2 v11
- **Arquitectura:** MVC (Modelo - Vista - Controlador)
- **Seguridad:** bcrypt (password_hash/password_verify), sesiones PHP,
  prepared statements PDO, htmlspecialchars en salidas HTML
