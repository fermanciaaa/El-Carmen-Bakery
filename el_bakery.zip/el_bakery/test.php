<?php
/**
 * test.php — Generador de hash bcrypt
 * Úsalo UNA VEZ para generar la contraseña del admin inicial,
 * luego elimina o protege este archivo en producción.
 *
 * Uso: http://localhost/el_bakery/test.php?pass=tuContraseña
 */

$pass = $_GET['pass'] ?? '';

if ($pass) {
    $hash = password_hash($pass, PASSWORD_BCRYPT, ['cost' => 12]);
    echo "<pre>";
    echo "Contraseña ingresada : " . htmlspecialchars($pass) . "\n";
    echo "Hash generado        : " . $hash . "\n\n";
    echo "Copia y pega este SQL en MySQL:\n\n";
    echo "UPDATE usuarios SET contrasenia = '" . $hash . "' WHERE correo = 'admin@elbakery.com';";
    echo "</pre>";
} else {
    echo "<p>Agrega <code>?pass=tuContraseña</code> en la URL para generar el hash.</p>";
    echo "<p>Ejemplo: <code>http://localhost/el_bakery/test.php?pass=Admin123</code></p>";
}
