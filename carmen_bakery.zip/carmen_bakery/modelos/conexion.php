<?php
class Conexion
{
    public function conx_pdo()
    {
        $conexion = null;
        try {
            $conexion = new PDO(
                'mysql:host=localhost;dbname=el_bakery;port=3307;charset=utf8mb4','root','');
            // Activar modo excepción para capturar errores SQL fácilmente
            $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $ex) {
            // En producción no mostrar detalles; aquí los mostramos para desarrollo
            echo "Error de conexión: " . $ex->getMessage();
            exit;
        }
        return $conexion;
    }
}
