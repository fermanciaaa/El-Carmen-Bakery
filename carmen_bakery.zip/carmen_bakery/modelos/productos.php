<?php
class Productos extends Conexion
{
    //  LECTURA
    
    /*Retorna todos los productos con su categoría y estado.*/
    public function obtener_todos()
    {
        $sql = "SELECT p.id_producto_catalogo, p.nombre_producto, p.descripcion,
                       p.precio_venta, c.nombre_categoria, e.nombre AS estado
                  FROM producto_catalogo p
                  JOIN categoria c ON c.id_categoria = p.id_categoria
                  JOIN estado    e ON e.id_estado    = p.id_estado
                 ORDER BY p.id_producto_catalogo ASC";
        $conx = parent::conx_pdo();
        $stm  = $conx->prepare($sql);
        $stm->execute();
        return $stm->fetchAll(PDO::FETCH_ASSOC);
    }

    /*Retorna un producto por su ID (para edición).*/
    public function obtener_por_id($id)
    {
        $sql = "SELECT id_producto_catalogo, nombre_producto, descripcion,
                       precio_venta, id_categoria, id_estado
                  FROM producto_catalogo
                 WHERE id_producto_catalogo = :id";
        $conx = parent::conx_pdo();
        $stm  = $conx->prepare($sql);
        $stm->bindParam(':id', $id, PDO::PARAM_INT);
        $stm->execute();
        return $stm->fetch(PDO::FETCH_ASSOC);
    }

    /* Retorna todas las categorías (para el <select> del formulario).*/
    public function obtener_categorias()
    {
        $sql  = "SELECT id_categoria, nombre_categoria FROM categoria ORDER BY nombre_categoria ASC";
        $conx = parent::conx_pdo();
        $stm  = $conx->prepare($sql);
        $stm->execute();
        return $stm->fetchAll(PDO::FETCH_ASSOC);
    }

    //  ESCRITURA

    /*Inserta un producto nuevo en el catálogo.*/
    public function insertar($nombre, $descripcion, $precio, $id_categoria)
    {
        try {
            $sql = "INSERT INTO producto_catalogo
                        (nombre_producto, descripcion, precio_venta, id_categoria, id_estado)
                    VALUES (:nombre, :descripcion, :precio, :id_categoria, 1)";
            $conx = parent::conx_pdo();
            $stm  = $conx->prepare($sql);
            $stm->bindParam(':nombre',       $nombre);
            $stm->bindParam(':descripcion',  $descripcion);
            $stm->bindParam(':precio',       $precio);
            $stm->bindParam(':id_categoria', $id_categoria, PDO::PARAM_INT);
            $stm->execute();
            return true;
        } catch (PDOException $e) {
            return "Error al registrar producto: " . $e->getMessage();
        }
    }

    /* Actualiza los datos de un producto existente.*/
    public function actualizar($id, $nombre, $descripcion, $precio, $id_categoria)
    {
        try {
            $sql = "UPDATE producto_catalogo
                       SET nombre_producto = :nombre,
                           descripcion     = :descripcion,
                           precio_venta    = :precio,
                           id_categoria    = :id_categoria
                     WHERE id_producto_catalogo = :id";
            $conx = parent::conx_pdo();
            $stm  = $conx->prepare($sql);
            $stm->bindParam(':nombre',       $nombre);
            $stm->bindParam(':descripcion',  $descripcion);
            $stm->bindParam(':precio',       $precio);
            $stm->bindParam(':id_categoria', $id_categoria, PDO::PARAM_INT);
            $stm->bindParam(':id',           $id,           PDO::PARAM_INT);
            $stm->execute();
            return true;
        } catch (PDOException $e) {
            return "Error al actualizar producto: " . $e->getMessage();
        }
    }

    /**Cambia el estado del producto (activo ↔ inactivo).
     * Un producto inactivo no aparece disponible para ventas.*/
    public function cambiar_estado($id, $id_estado)
    {
        try {
            $sql = "UPDATE producto_catalogo SET id_estado = :estado WHERE id_producto_catalogo = :id";
            $conx = parent::conx_pdo();
            $stm  = $conx->prepare($sql);
            $stm->bindParam(':estado', $id_estado, PDO::PARAM_INT);
            $stm->bindParam(':id',     $id,        PDO::PARAM_INT);
            $stm->execute();
            return true;
        } catch (PDOException $e) {
            return "Error al cambiar estado: " . $e->getMessage();
        }
    }

    //  GENERACIÓN DE HTML
    /*Genera las filas <tr> de la tabla de productos para el panel.*/
    public function vista_tabla()
    {
        $productos = $this->obtener_todos();
        $html = '';
        $n    = 0;

        foreach ($productos as $p) {
            $n++;
            $activo = ($p['estado'] === 'Activo');

            $btn_estado = $activo
                ? '<button class="btn btn-sm btn-danger btn-estado"
                           data-id="'    . $p['id_producto_catalogo'] . '"
                           data-nuevo="2"
                           title="Desactivar">
                       <i class="bi bi-toggle-on"></i>
                   </button>'
                : '<button class="btn btn-sm btn-success btn-estado"
                           data-id="'    . $p['id_producto_catalogo'] . '"
                           data-nuevo="1"
                           title="Activar">
                       <i class="bi bi-toggle-off"></i>
                   </button>';

            $html .= '<tr>';
            $html .= '<td>' . $n . '</td>';
            $html .= '<td>' . htmlspecialchars($p['nombre_producto'])  . '</td>';
            $html .= '<td>' . htmlspecialchars($p['descripcion'] ?? '—') . '</td>';
            $html .= '<td>$' . number_format($p['precio_venta'], 2) . '</td>';
            $html .= '<td>' . htmlspecialchars($p['nombre_categoria']) . '</td>';
            $html .= '<td><span class="badge ' . ($activo ? 'bg-success' : 'bg-secondary') . '">'
                           . htmlspecialchars($p['estado']) . '</span></td>';
            $html .= '<td class="text-center">';
            $html .=   '<button class="btn btn-sm btn-warning btn-editar me-1"
                                data-id="' . $p['id_producto_catalogo'] . '"
                                title="Editar">
                            <i class="bi bi-pencil-fill"></i>
                        </button>';
            $html .=   $btn_estado;
            $html .= '</td>';
            $html .= '</tr>';
        }
        return $html;
    }

    /*Genera las opciones <option> de categorías.*/
    public function vista_categorias($seleccionado = null)
    {
        $cats  = $this->obtener_categorias();
        $html  = '<option value="">-- Seleccione categoría --</option>';
        foreach ($cats as $c) {
            $sel   = ($c['id_categoria'] == $seleccionado) ? 'selected' : '';
            $html .= '<option value="' . $c['id_categoria'] . '" ' . $sel . '>'
                   . htmlspecialchars($c['nombre_categoria']) . '</option>';
        }
        return $html;
    }
}
