<?php
class Login extends Conexion
{
    /*Verifica si el correo y contraseña corresponden a un usuario activo.*/
    public function verificar($correo, $password)
    {
        // Buscamos el usuario activo por correo
        // Solo usuarios con estado Activo (id_estado = 1)
        $sql = "SELECT u.id_usuario, u.nombre, u.apellido, u.correo,
                       u.contrasenia, r.nombre AS rol
                  FROM usuarios u
                  JOIN roles    r ON r.id_rol    = u.id_rol
                 WHERE u.correo    = :correo
                   AND u.id_estado = 1";

        $conx = parent::conx_pdo();
        $stm  = $conx->prepare($sql);
        $stm->bindParam(':correo', $correo);
        $stm->execute();
        $usuario = $stm->fetch(PDO::FETCH_ASSOC);

        // password_verify compara el texto plano con el hash bcrypt almacenado
        if ($usuario && password_verify($password, $usuario['contrasenia'])) {
            return $usuario;   // retorna el arreglo con los datos del usuario
        }
        return false;
    }
}
