<?php
class Usuarios extends Conexion
{
    //  LECTURA

    /*Retorna todos los usuarios con su rol y estado (para la tabla del panel).*/
    public function obtener_todos()
    {
        $sql = "SELECT u.id_usuario, u.nombre, u.apellido, u.dui,
                       u.correo, r.nombre AS rol, e.nombre AS estado
                  FROM usuarios u
                  JOIN roles  r ON r.id_rol    = u.id_rol
                  JOIN estado e ON e.id_estado = u.id_estado
                 ORDER BY u.id_usuario ASC";
        $conx = parent::conx_pdo();
        $stm  = $conx->prepare($sql);
        $stm->execute();
        return $stm->fetchAll(PDO::FETCH_ASSOC);
    }

    /*Retorna un usuario específico por su ID (para pre-llenar el formulario de edición).*/
    public function obtener_por_id($id_usuario)
    {
        $sql = "SELECT id_usuario, nombre, apellido, dui, correo, id_rol, id_estado
                  FROM usuarios
                 WHERE id_usuario = :id";
        $conx = parent::conx_pdo();
        $stm  = $conx->prepare($sql);
        $stm->bindParam(':id', $id_usuario, PDO::PARAM_INT);
        $stm->execute();
        return $stm->fetch(PDO::FETCH_ASSOC);
    }

    /*Retorna todos los roles disponibles (para poblar el <select> del formulario).*/
    public function obtener_roles()
    {
        $sql  = "SELECT id_rol, nombre FROM roles ORDER BY id_rol ASC";
        $conx = parent::conx_pdo();
        $stm  = $conx->prepare($sql);
        $stm->execute();
        return $stm->fetchAll(PDO::FETCH_ASSOC);
    }

    //  ESCRITURA

    /*Inserta un nuevo usuario.
     * La contraseña se hashea con bcrypt antes de guardarla.
     * @return true|string  true si OK, mensaje de error si falla */
    public function insertar($nombre, $apellido, $dui, $correo, $password, $id_rol)
    {
        try {
            // Generar hash bcrypt (costo 12 es un buen balance seguridad/velocidad)
            $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

            $sql = "INSERT INTO usuarios (nombre, apellido, dui, correo, contrasenia, id_rol, id_estado)
                    VALUES (:nombre, :apellido, :dui, :correo, :contrasenia, :id_rol, 1)";
            $conx = parent::conx_pdo();
            $stm  = $conx->prepare($sql);
            $stm->bindParam(':nombre',      $nombre);
            $stm->bindParam(':apellido',    $apellido);
            $stm->bindParam(':dui',         $dui);
            $stm->bindParam(':correo',      $correo);
            $stm->bindParam(':contrasenia', $hash);
            $stm->bindParam(':id_rol',      $id_rol, PDO::PARAM_INT);
            $stm->execute();
            return true;
        } catch (PDOException $e) {
            // Código 23000 = violación de clave única (DUI o correo duplicado)
            if ($e->getCode() === '23000') {
                return "El DUI o correo ya están registrados.";
            }
            return "Error al registrar: " . $e->getMessage();
        }
    }

    /* Actualiza los datos de un usuario existente.
     * Si se envía contraseña nueva se rehashea; si viene vacía se conserva la actual.*/
    public function actualizar($id_usuario, $nombre, $apellido, $dui, $correo, $id_rol, $password = null)
    {
        try {
            $conx = parent::conx_pdo();

            if (!empty($password)) {
                // El usuario quiere cambiar su contraseña
                $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
                $sql  = "UPDATE usuarios
                            SET nombre = :nombre, apellido = :apellido, dui = :dui,
                                correo = :correo, id_rol = :id_rol, contrasenia = :contrasenia
                          WHERE id_usuario = :id";
                $stm  = $conx->prepare($sql);
                $stm->bindParam(':contrasenia', $hash);
            } else {
                // Actualizar todo excepto la contraseña
                $sql = "UPDATE usuarios
                           SET nombre = :nombre, apellido = :apellido, dui = :dui,
                               correo = :correo, id_rol = :id_rol
                         WHERE id_usuario = :id";
                $stm = $conx->prepare($sql);
            }

            $stm->bindParam(':nombre',    $nombre);
            $stm->bindParam(':apellido',  $apellido);
            $stm->bindParam(':dui',       $dui);
            $stm->bindParam(':correo',    $correo);
            $stm->bindParam(':id_rol',    $id_rol, PDO::PARAM_INT);
            $stm->bindParam(':id',        $id_usuario, PDO::PARAM_INT);
            $stm->execute();
            return true;
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                return "El DUI o correo ya están en uso por otro usuario.";
            }
            return "Error al actualizar: " . $e->getMessage();
        }
    }

    /*Cambia el estado de un usuario (activo ↔ inactivo).
     * No eliminamos registros — solo desactivamos (soft delete).*/
    public function cambiar_estado($id_usuario, $id_estado)
    {
        try {
            $sql = "UPDATE usuarios SET id_estado = :estado WHERE id_usuario = :id";
            $conx = parent::conx_pdo();
            $stm  = $conx->prepare($sql);
            $stm->bindParam(':estado', $id_estado, PDO::PARAM_INT);
            $stm->bindParam(':id',     $id_usuario, PDO::PARAM_INT);
            $stm->execute();
            return true;
        } catch (PDOException $e) {
            return "Error al cambiar estado: " . $e->getMessage();
        }
    }

    //  GENERACIÓN DE HTML (para respuestas AJAX)

    /* Genera las filas <tr> de la tabla de usuarios para inyectarlas en el panel.
     * Cada fila incluye botones de Editar y Activar/Desactivar.*/
    public function vista_tabla()
    {
        $usuarios = $this->obtener_todos();
        $html = '';
        $n    = 0;

        foreach ($usuarios as $u) {
            $n++;
            $activo = ($u['estado'] === 'Activo');

            // Botón de estado: verde si activo, rojo si inactivo
            $btn_estado = $activo
                ? '<button class="btn btn-sm btn-danger btn-estado"
                           data-id="'  . $u['id_usuario'] . '"
                           data-nuevo="2"
                           title="Desactivar">
                       <i class="bi bi-toggle-on"></i>
                   </button>'
                : '<button class="btn btn-sm btn-success btn-estado"
                           data-id="'  . $u['id_usuario'] . '"
                           data-nuevo="1"
                           title="Activar">
                       <i class="bi bi-toggle-off"></i>
                   </button>';

            $html .= '<tr>';
            $html .= '<td>' . $n . '</td>';
            $html .= '<td>' . htmlspecialchars($u['nombre'])   . '</td>';
            $html .= '<td>' . htmlspecialchars($u['apellido']) . '</td>';
            $html .= '<td>' . htmlspecialchars($u['dui'])      . '</td>';
            $html .= '<td>' . htmlspecialchars($u['correo'])   . '</td>';
            $html .= '<td>' . htmlspecialchars($u['rol'])      . '</td>';
            $html .= '<td><span class="badge ' . ($activo ? 'bg-success' : 'bg-secondary') . '">'
                           . htmlspecialchars($u['estado']) . '</span></td>';
            $html .= '<td class="text-center">';
            $html .=   '<button class="btn btn-sm btn-warning btn-editar me-1"
                                data-id="' . $u['id_usuario'] . '"
                                title="Editar">
                            <i class="bi bi-pencil-fill"></i>
                        </button>';
            $html .=   $btn_estado;
            $html .= '</td>';
            $html .= '</tr>';
        }
        return $html;
    }

    /* Genera las opciones <option> de roles para el <select> del formulario.
     * Recibe el id_rol seleccionado para marcarlo como "selected" en edición. */
    public function vista_roles($seleccionado = null)
    {
        $roles = $this->obtener_roles();
        $html  = '<option value="">-- Seleccione rol --</option>';
        foreach ($roles as $r) {
            $sel   = ($r['id_rol'] == $seleccionado) ? 'selected' : '';
            $html .= '<option value="' . $r['id_rol'] . '" ' . $sel . '>'
                   . htmlspecialchars($r['nombre']) . '</option>';
        }
        return $html;
    }
}
