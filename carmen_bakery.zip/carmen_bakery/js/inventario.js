$(function () {
    // DataTable
    const tabla = $('#tablaInventario').DataTable({
        responsive:  true,
        pageLength:  10,
        lengthMenu:  [5, 10, 25],
        order:       [[0, 'asc']],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.0.3/i18n/es-ES.json' }
    });

    const modalEl  = document.getElementById('modalInventario');
    const modalObj = new bootstrap.Modal(modalEl);

    // Helpers
    function recargarTabla() {
        $.ajax({
            url:    '../controladores/controlador_inventario.php',
            method: 'POST',
            data:   { operacion: 2 },
            success: function (html) {
                tabla.clear().draw();
                $('#tablaInventario tbody').html(html);
                tabla.rows.add($('#tablaInventario tbody tr')).draw(false);
            }
        });
    }

    function alertOk(msg)    { Swal.fire({ icon: 'success', title: '¡Listo!',  text: msg, timer: 1800, showConfirmButton: false }); }
    function alertError(msg) { Swal.fire({ icon: 'error',   title: 'Error',    text: msg, confirmButtonColor: '#dc3545' }); }
    function alertWarn(msg)  { Swal.fire({ icon: 'warning', title: 'Atención', text: msg }); }

    // Eventos
    $(document).on('click', '.btn-ajustar', function () {
        const btn = $(this);
        $('#id_inventario').val(btn.data('id'));
        $('#nombre_producto_inv').val(btn.data('nombre'));
        $('#stock_actual_inv').val(btn.data('stock'));
        $('#stock_minimo_inv').val(btn.data('minimo'));
        modalObj.show();
    });

    $('#btn-guardar-inventario').on('click', function () {
        const id_inv    = parseInt($('#id_inventario').val());
        const stock     = parseInt($('#stock_actual_inv').val());
        const stock_min = parseInt($('#stock_minimo_inv').val());

        if (isNaN(stock) || stock < 0) {
            alertWarn('El stock no puede ser negativo.'); return;
        }
        if (isNaN(stock_min) || stock_min < 0) {
            alertWarn('El stock mínimo no puede ser negativo.'); return;
        }

        if (stock === 0) {
            Swal.fire({
                title: '¿Stock en cero?',
                text:  'Estás ajustando el stock a 0 unidades. ¿Es correcto?',
                icon:  'warning',
                showCancelButton:  true,
                confirmButtonText: 'Sí, guardar',
                cancelButtonText:  'Revisar'
            }).then(result => {
                if (result.isConfirmed) guardarAjuste(id_inv, stock, stock_min);
            });
        } else {
            guardarAjuste(id_inv, stock, stock_min);
        }
    });

    function guardarAjuste(id_inv, stock, stock_min) {
        $.ajax({
            url:    '../controladores/controlador_inventario.php',
            method: 'POST',
            data:   { operacion: 1, id_inventario: id_inv, stock_actual: stock, stock_minimo: stock_min },
            success: function (rs) {
                if (rs.trim() === '1') {
                    modalObj.hide();
                    alertOk('Stock ajustado correctamente.');
                    recargarTabla();
                } else {
                    alertError(rs);
                }
            }
        });
    }
});
