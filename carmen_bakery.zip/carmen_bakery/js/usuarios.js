$(function () {
    // DataTable
    const tabla = $('#tablaUsuarios').DataTable({
        responsive:  true,
        pageLength:  10,
        lengthMenu:  [5, 10, 25, 50],
        order:       [[0, 'asc']],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.0.3/i18n/es-ES.json' }
    });

    const modalEl  = document.getElementById('modalUsuario');
    const modalObj = new bootstrap.Modal(modalEl);

    // Helpers
    function abrirModalNuevo() {
        $('#tituloModalUsuario').text('Nuevo Usuario');
        $('#id_usuario').val('0');
        $('#nombre, #apellido, #dui, #correo_usuario, #password_usuario').val('');
        $('#id_rol').val('');
        $('#lblPassword').html('Contraseña <span class="text-danger">*</span>');
        $('#avisoPass').addClass('d-none');
        $('#password_usuario').attr('required', true);
        modalObj.show();
    }

    function abrirModalEditar(id_usuario) {
        $.ajax({
            url:    '../controladores/controlador_usuarios.php',
            method: 'POST',
            data:   { operacion: 4, id_usuario },
            success: function (respuesta) {
                const u = JSON.parse(respuesta);
                if (u.error) { alertError(u.error); return; }
                $('#tituloModalUsuario').text('Editar Usuario');
                $('#id_usuario').val(u.id_usuario);
                $('#nombre').val(u.nombre);
                $('#apellido').val(u.apellido);
                $('#dui').val(u.dui);
                $('#correo_usuario').val(u.correo);
                $('#id_rol').val(u.id_rol);
                $('#password_usuario').val('');
                $('#lblPassword').html('Contraseña nueva');
                $('#avisoPass').removeClass('d-none');
                $('#password_usuario').removeAttr('required');
                modalObj.show();
            }
        });
    }

    function recargarTabla() {
        $.ajax({
            url:    '../controladores/controlador_usuarios.php',
            method: 'POST',
            data:   { operacion: 5 },
            success: function (html) {
                tabla.clear().draw();
                $('#tablaUsuarios tbody').html(html);
                tabla.rows.add($('#tablaUsuarios tbody tr')).draw(false);
            }
        });
    }

    function alertOk(msg)    { Swal.fire({ icon: 'success', title: '¡Listo!',  text: msg, timer: 1800, showConfirmButton: false }); }
    function alertError(msg) { Swal.fire({ icon: 'error',   title: 'Error',    text: msg, confirmButtonColor: '#dc3545' }); }
    function alertWarn(msg)  { Swal.fire({ icon: 'warning', title: 'Atención', text: msg }); }

    // Eventos
    $('#btn-nuevo-usuario').on('click', abrirModalNuevo);

    $(document).on('click', '.btn-editar', function () {
        abrirModalEditar($(this).data('id'));
    });

    $(document).on('click', '.btn-estado', function () {
        const id_usuario = $(this).data('id');
        const nuevo      = $(this).data('nuevo');
        const accion     = nuevo == 1 ? 'activar' : 'desactivar';

        Swal.fire({
            title:             `¿${accion.charAt(0).toUpperCase() + accion.slice(1)} usuario?`,
            text:              'Puedes revertir este cambio en cualquier momento.',
            icon:              'question',
            showCancelButton:  true,
            confirmButtonText: 'Sí, ' + accion,
            cancelButtonText:  'Cancelar',
            confirmButtonColor: nuevo == 1 ? '#198754' : '#dc3545'
        }).then(result => {
            if (!result.isConfirmed) return;
            $.ajax({
                url:    '../controladores/controlador_usuarios.php',
                method: 'POST',
                data:   { operacion: 3, id_usuario, id_estado: nuevo },
                success: function (rs) {
                    if (rs.trim() === '1') { alertOk('Estado actualizado.'); recargarTabla(); }
                    else                   { alertError(rs); }
                }
            });
        });
    });

    $('#btn-guardar-usuario').on('click', function () {
        const id_usuario = parseInt($('#id_usuario').val());
        const nombre     = $('#nombre').val().trim();
        const apellido   = $('#apellido').val().trim();
        const dui        = $('#dui').val().trim();
        const correo     = $('#correo_usuario').val().trim();
        const id_rol     = parseInt($('#id_rol').val());
        const password   = $('#password_usuario').val().trim();

        if (!nombre || !apellido || !dui || !correo || !id_rol) {
            alertWarn('Complete todos los campos obligatorios.'); return;
        }
        if (!/^\d{9}$/.test(dui)) {
            alertWarn('El DUI debe tener exactamente 9 dígitos numéricos.'); return;
        }
        if (id_usuario === 0 && !password) {
            alertWarn('La contraseña es obligatoria para nuevos usuarios.'); return;
        }

        const operacion = id_usuario === 0 ? 1 : 2;

        $.ajax({
            url:    '../controladores/controlador_usuarios.php',
            method: 'POST',
            data:   { operacion, id_usuario, nombre, apellido, dui, correo, id_rol, password },
            success: function (rs) {
                if (rs.trim() === '1') {
                    modalObj.hide();
                    alertOk(operacion === 1 ? 'Usuario registrado.' : 'Usuario actualizado.');
                    recargarTabla();
                } else {
                    alertError(rs);
                }
            }
        });
    });
});
