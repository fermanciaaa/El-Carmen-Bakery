$(function () {
    // DataTable
    const tabla = $('#tablaProductos').DataTable({
        responsive:  true,
        pageLength:  10,
        lengthMenu:  [5, 10, 25],
        order:       [[0, 'asc']],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.0.3/i18n/es-ES.json' }
    });

    const modalEl  = document.getElementById('modalProducto');
    const modalObj = new bootstrap.Modal(modalEl);

    // Helpers
    function abrirModalNuevo() {
        $('#tituloModalProducto').text('Nuevo Producto');
        $('#id_producto_catalogo').val('0');
        $('#nombre_producto, #descripcion, #precio_venta').val('');
        $('#id_categoria').val('');
        modalObj.show();
    }

    function abrirModalEditar(id) {
        $.ajax({
            url:    '../controladores/controlador_productos.php',
            method: 'POST',
            data:   { operacion: 4, id_producto_catalogo: id },
            success: function (rs) {
                const p = JSON.parse(rs);
                if (p.error) { alertError(p.error); return; }
                $('#tituloModalProducto').text('Editar Producto');
                $('#id_producto_catalogo').val(p.id_producto_catalogo);
                $('#nombre_producto').val(p.nombre_producto);
                $('#descripcion').val(p.descripcion ?? '');
                $('#precio_venta').val(p.precio_venta);
                $('#id_categoria').val(p.id_categoria);
                modalObj.show();
            }
        });
    }

    function recargarTabla() {
        $.ajax({
            url:    '../controladores/controlador_productos.php',
            method: 'POST',
            data:   { operacion: 5 },
            success: function (html) {
                tabla.clear().draw();
                $('#tablaProductos tbody').html(html);
                tabla.rows.add($('#tablaProductos tbody tr')).draw(false);
            }
        });
    }

    function alertOk(msg)    { Swal.fire({ icon: 'success', title: '¡Listo!', text: msg, timer: 1800, showConfirmButton: false }); }
    function alertError(msg) { Swal.fire({ icon: 'error',   title: 'Error',   text: msg, confirmButtonColor: '#dc3545' }); }
    function alertWarn(msg)  { Swal.fire({ icon: 'warning', title: 'Atención', text: msg }); }

    // Eventos

    $('#btn-nuevo-producto').on('click', abrirModalNuevo);

    $(document).on('click', '.btn-editar', function () {
        abrirModalEditar($(this).data('id'));
    });

    $(document).on('click', '.btn-estado', function () {
        const id    = $(this).data('id');
        const nuevo = $(this).data('nuevo');
        const accion = nuevo == 1 ? 'activar' : 'desactivar';

        Swal.fire({
            title: `¿${accion.charAt(0).toUpperCase() + accion.slice(1)} producto?`,
            text:  'Un producto inactivo no aparece disponible para ventas.',
            icon:  'question',
            showCancelButton: true,
            confirmButtonText: 'Sí, ' + accion,
            cancelButtonText:  'Cancelar',
            confirmButtonColor: nuevo == 1 ? '#198754' : '#dc3545'
        }).then(result => {
            if (!result.isConfirmed) return;
            $.ajax({
                url:    '../controladores/controlador_productos.php',
                method: 'POST',
                data:   { operacion: 3, id_producto_catalogo: id, id_estado: nuevo },
                success: function (rs) {
                    rs.trim() === '1' ? (alertOk('Estado actualizado.'), recargarTabla()) : alertError(rs);
                }
            });
        });
    });

    $('#btn-guardar-producto').on('click', function () {
        const id          = parseInt($('#id_producto_catalogo').val());
        const nombre      = $('#nombre_producto').val().trim();
        const descripcion = $('#descripcion').val().trim();
        const precio      = parseFloat($('#precio_venta').val());
        const id_cat      = parseInt($('#id_categoria').val());

        if (!nombre || !precio || precio <= 0 || !id_cat) {
            alertWarn('Complete los campos obligatorios con valores válidos.'); return;
        }

        const operacion = id === 0 ? 1 : 2;

        $.ajax({
            url:    '../controladores/controlador_productos.php',
            method: 'POST',
            data:   { operacion, id_producto_catalogo: id, nombre_producto: nombre, descripcion, precio_venta: precio, id_categoria: id_cat },
            success: function (rs) {
                if (rs.trim() === '1') {
                    modalObj.hide();
                    alertOk(operacion === 1 ? 'Producto registrado.' : 'Producto actualizado.');
                    recargarTabla();
                } else {
                    alertError(rs);
                }
            }
        });
    });
});
