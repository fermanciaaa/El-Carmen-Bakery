<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>El Carmen Bakery — Iniciar Sesión</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body class="login-bg d-flex justify-content-center align-items-center min-vh-100">

<div class="login-card card shadow-lg" style="width:100%;max-width:420px;">

    <!-- Cabecera con logo -->
    <div class="card-header-logo">
        <img src="assets/logo.png" alt="El Carmen Bakery"
             style="width:130px;height:130px;object-fit:contain;border-radius:50%;">
    </div>

    <div class="p-4">
        <h5 class="fw-bold text-center mb-1" style="color:var(--bakery-cafe)">Bienvenido</h5>
        <p class="text-center text-muted small mb-4">Sistema de Punto de Venta</p>

        <div class="mb-3">
            <label class="form-label fw-semibold">Correo electrónico</label>
            <div class="input-group">
                <span class="input-group-text" style="background:var(--bakery-crema);border-color:#d8c4b8">
                    <i class="bi bi-envelope" style="color:var(--bakery-cafe)"></i>
                </span>
                <input type="email" id="correo" class="form-control" placeholder="usuario@elbakery.com"
                       style="border-color:#d8c4b8" autocomplete="off">
            </div>
        </div>

        <div class="mb-4">
            <label class="form-label fw-semibold">Contraseña</label>
            <div class="input-group">
                <span class="input-group-text" style="background:var(--bakery-crema);border-color:#d8c4b8">
                    <i class="bi bi-lock" style="color:var(--bakery-cafe)"></i>
                </span>
                <input type="password" id="password" class="form-control"
                       placeholder="••••••••" style="border-color:#d8c4b8">
                <button type="button" class="btn btn-outline-secondary" id="togglePass"
                        style="border-color:#d8c4b8">
                    <i class="bi bi-eye" id="iconoOjo"></i>
                </button>
            </div>
        </div>

        <button id="btnLogin" class="btn btn-bakery w-100 py-2">
            <i class="bi bi-box-arrow-in-right me-1"></i> Ingresar
        </button>
    </div>
</div>

<script>
$('#togglePass').on('click', function () {
    const c = $('#password'), i = $('#iconoOjo');
    if (c.attr('type') === 'password') { c.attr('type','text');     i.removeClass('bi-eye').addClass('bi-eye-slash'); }
    else                               { c.attr('type','password'); i.removeClass('bi-eye-slash').addClass('bi-eye'); }
});

$('#btnLogin').on('click', function () {
    const correo   = $('#correo').val().trim();
    const password = $('#password').val().trim();
    if (!correo || !password) {
        Swal.fire({ icon:'warning', title:'Campos vacíos', text:'Complete todos los campos.' });
        return;
    }
    $.ajax({
        url: 'controladores/login.php', method: 'POST', dataType: 'json',
        data: { correo, password },
        success: function (res) {
            if (res.success) {
                Swal.fire({ icon:'success', title:'¡Bienvenido!', timer:1400, showConfirmButton:false })
                    .then(() => window.location.href = 'vistas/panel.php');
            } else {
                Swal.fire({ icon:'error', title:'Acceso denegado', text:res.msg, confirmButtonColor:'#b85c65' });
            }
        },
        error: function () {
            Swal.fire({ icon:'error', title:'Error', text:'No se pudo conectar con el servidor.' });
        }
    });
});

// Enter en cualquier campo dispara login
$('#correo, #password').on('keypress', function(e){
    if(e.which === 13) $('#btnLogin').click();
});
</script>
</body>
</html>
