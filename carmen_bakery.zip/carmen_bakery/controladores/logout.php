<?php
session_start();
session_unset();    // limpiar todas las variables de sesión
session_destroy();  // destruir el archivo de sesión en el servidor

// Redireccion al login
header('Location: ../index.php');
exit;
