<?php
session_start();

// Verificar que haya una sesión activa antes de operar
if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'msg' => 'Sesión expirada.']);
    exit;
}

// Solo el Administrador puede gestionar usuarios.
// Si otro rol intenta operar, se rechaza aquí antes de llegar al switch.
$es_admin = ($_SESSION['rol'] === 'Administrador');

// Operaciones protegidas: 1=insertar, 2=actualizar, 3=cambiar estado
$operacion_actual = (int) ($_REQUEST['operacion'] ?? 0);
$operaciones_protegidas = [1, 2, 3];

if (in_array($operacion_actual, $operaciones_protegidas) && !$es_admin) {
    echo "No tienes permisos para realizar esta acción.";
    exit;
}

require_once '../modelos/conexion.php';
require_once '../modelos/usuarios.php';

$modelo = new Usuarios();

if (isset($_REQUEST['operacion'])) {

    switch ((int) $_REQUEST['operacion']) {

        // 1: Insertar nuevo usuario
        case 1:
            $nombre    = trim($_POST['nombre']    ?? '');
            $apellido  = trim($_POST['apellido']  ?? '');
            $dui       = trim($_POST['dui']       ?? '');
            $correo    = trim($_POST['correo']    ?? '');
            $password  = trim($_POST['password']  ?? '');
            $id_rol    = (int) ($_POST['id_rol']  ?? 0);

            // Validación básica 
            if (empty($nombre) || empty($apellido) || empty($dui) || empty($correo) || empty($password) || $id_rol === 0) {
                echo "Todos los campos son obligatorios.";
                break;
            }

            $rs = $modelo->insertar($nombre, $apellido, $dui, $correo, $password, $id_rol);
            echo ($rs === true) ? "1" : $rs;
            break;

        // 2: Actualizar usuario
        case 2:
            $id_usuario = (int) ($_POST['id_usuario'] ?? 0);
            $nombre     = trim($_POST['nombre']    ?? '');
            $apellido   = trim($_POST['apellido']  ?? '');
            $dui        = trim($_POST['dui']       ?? '');
            $correo     = trim($_POST['correo']    ?? '');
            $id_rol     = (int) ($_POST['id_rol']  ?? 0);
            $password   = trim($_POST['password']  ?? '');   // puede venir vacío

            if ($id_usuario === 0 || empty($nombre) || empty($apellido) || empty($dui) || empty($correo) || $id_rol === 0) {
                echo "Datos incompletos para actualizar.";
                break;
            }

            $rs = $modelo->actualizar($id_usuario, $nombre, $apellido, $dui, $correo, $id_rol, $password ?: null);
            echo ($rs === true) ? "1" : $rs;
            break;

        // 3: Cambiar estado
        case 3:
            $id_usuario = (int) ($_POST['id_usuario'] ?? 0);
            $id_estado  = (int) ($_POST['id_estado']  ?? 0);

            // Evitar que el usuario logueado se desactive a sí mismo
            if ($id_usuario === (int) $_SESSION['id_usuario']) {
                echo "No puedes cambiar tu propio estado.";
                break;
            }

            // Evitar desactivar al único administrador
            // (protección extra para no dejar el sistema sin admin)
            $rs = $modelo->cambiar_estado($id_usuario, $id_estado);
            echo ($rs === true) ? "1" : $rs;
            break;

        // 4: Cargar datos para edición
        case 4:
            $id_usuario = (int) ($_POST['id_usuario'] ?? 0);
            $usuario    = $modelo->obtener_por_id($id_usuario);

            if ($usuario) {
                // Retornamos JSON para que JS llene los inputs del modal
                echo json_encode($usuario);
            } else {
                echo json_encode(['error' => 'Usuario no encontrado.']);
            }
            break;

        // 5: Recargar tabla
        case 5:
            echo $modelo->vista_tabla();
            break;

        // 6: Cargar opciones de roles
        case 6:
            $seleccionado = (int) ($_POST['seleccionado'] ?? 0);
            echo $modelo->vista_roles($seleccionado ?: null);
            break;

        default:
            echo "Operación no reconocida.";
            break;
    }
}
