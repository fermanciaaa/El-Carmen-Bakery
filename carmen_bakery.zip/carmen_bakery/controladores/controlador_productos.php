<?php
session_start();

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'msg' => 'Sesión expirada.']);
    exit;
}

require_once '../modelos/conexion.php';
require_once '../modelos/productos.php';

$modelo = new Productos();

if (isset($_REQUEST['operacion'])) {

    switch ((int) $_REQUEST['operacion']) {

        // 1: Insertar producto
        case 1:
            $nombre      = trim($_POST['nombre_producto'] ?? '');
            $descripcion = trim($_POST['descripcion']     ?? '');
            $precio      = (float) ($_POST['precio_venta'] ?? 0);
            $id_cat      = (int)   ($_POST['id_categoria'] ?? 0);

            if (empty($nombre) || $precio <= 0 || $id_cat === 0) {
                echo "Complete los campos obligatorios.";
                break;
            }

            $rs = $modelo->insertar($nombre, $descripcion, $precio, $id_cat);
            echo ($rs === true) ? "1" : $rs;
            break;

        // 2: Actualizar producto
        case 2:
            $id          = (int)   ($_POST['id_producto_catalogo'] ?? 0);
            $nombre      = trim($_POST['nombre_producto'] ?? '');
            $descripcion = trim($_POST['descripcion']     ?? '');
            $precio      = (float) ($_POST['precio_venta'] ?? 0);
            $id_cat      = (int)   ($_POST['id_categoria'] ?? 0);

            if ($id === 0 || empty($nombre) || $precio <= 0 || $id_cat === 0) {
                echo "Datos incompletos para actualizar.";
                break;
            }

            $rs = $modelo->actualizar($id, $nombre, $descripcion, $precio, $id_cat);
            echo ($rs === true) ? "1" : $rs;
            break;

        // 3: Cambiar estado
        case 3:
            $id        = (int) ($_POST['id_producto_catalogo'] ?? 0);
            $id_estado = (int) ($_POST['id_estado']            ?? 0);

            $rs = $modelo->cambiar_estado($id, $id_estado);
            echo ($rs === true) ? "1" : $rs;
            break;

        // 4: Cargar datos para edición
        case 4:
            $id      = (int) ($_POST['id_producto_catalogo'] ?? 0);
            $producto = $modelo->obtener_por_id($id);
            echo $producto ? json_encode($producto) : json_encode(['error' => 'Producto no encontrado.']);
            break;

        // 5: Recargar tabla
        case 5:
            echo $modelo->vista_tabla();
            break;

        // 6: Cargar opciones de categoría
        case 6:
            $seleccionado = (int) ($_POST['seleccionado'] ?? 0);
            echo $modelo->vista_categorias($seleccionado ?: null);
            break;

        default:
            echo "Operación no reconocida.";
            break;
    }
}
