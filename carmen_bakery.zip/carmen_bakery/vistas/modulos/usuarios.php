<!-- MÓDULO: USUARIOS
     Vista parcial incluida por panel.php según $modulo activo.
     Contiene: encabezado, tabla DataTables y modales de formulario.-->

<!-- Encabezado del módulo -->
<div class="d-flex justify-content-between align-items-center mb-3 mt-3">
    <h4 class="mb-0"><i class="bi bi-people-fill me-2 text-warning"></i>Gestión de Usuarios</h4>
    <?php if ($_SESSION['rol'] === 'Administrador'): ?>
        <button class="btn btn-bakery" id="btn-nuevo-usuario">
            <i class="bi bi-plus-lg me-1"></i> Nuevo Usuario
        </button>
    <?php endif; ?>
</div>

<!-- Tabla de usuarios -->
<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table id="tablaUsuarios" class="table table-striped table-bordered align-middle w-100">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>DUI</th>
                        <th>Correo</th>
                        <th>Rol</th>
                        <th>Estado</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Las filas se cargan con PHP al abrir el módulo -->
                    <?php echo $data_usuarios->vista_tabla(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>#</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>DUI</th>
                        <th>Correo</th>
                        <th>Rol</th>
                        <th>Estado</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<!-- MODAL: NUEVO / EDITAR USUARIO
     El mismo modal sirve para insertar y editar.
     El campo oculto 'id_usuario' indica el modo:
       0  → insertar (nuevo)
       >0 → actualizar (editar) -->
<div class="modal fade" id="modalUsuario" tabindex="-1" aria-labelledby="tituloModalUsuario">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header modal-header-bakery">
                <h5 class="modal-title" id="tituloModalUsuario">Nuevo Usuario</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <!-- Campo oculto: 0 = insertar, >0 = editar -->
                <input type="hidden" id="id_usuario" value="0">

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nombre <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="nombre" maxlength="100" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Apellido <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="apellido" maxlength="100" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">DUI <span class="text-danger">*</span></label>
                        <!-- 9 dígitos sin guión -->
                        <input type="text" class="form-control" id="dui" maxlength="9"
                               placeholder="000000000" pattern="\d{9}" required>
                        <div class="form-text">9 dígitos sin guión.</div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Correo electrónico <span class="text-danger">*</span></label>
                        <input type="email" class="form-control" id="correo_usuario" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Rol <span class="text-danger">*</span></label>
                        <select class="form-select" id="id_rol">
                            <!-- Se puebla con AJAX o PHP al abrir el modal -->
                            <?php echo $data_usuarios->vista_roles(); ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label" id="lblPassword">
                            Contraseña <span class="text-danger">*</span>
                        </label>
                        <input type="password" class="form-control" id="password_usuario"
                               autocomplete="new-password">
                        <!-- En modo edición se muestra este aviso -->
                        <div class="form-text d-none" id="avisoPass">
                            Deja en blanco para conservar la contraseña actual.
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button class="btn btn-bakery" id="btn-guardar-usuario">
                    <i class="bi bi-floppy-fill me-1"></i> Guardar
                </button>
            </div>
        </div>
    </div>
</div>
