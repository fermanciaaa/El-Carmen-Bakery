<!-- MÓDULO: INVENTARIO
     Muestra el stock actual de cada producto y permite ajustes manuales.
     El incremento automático lo gestionan los triggers de la BD.-->

<div class="d-flex justify-content-between align-items-center mb-3 mt-3">
    <h4 class="mb-0">
        <i class="bi bi-clipboard2-data-fill me-2 text-warning"></i>Inventario
        <?php if ($alertas_inv > 0): ?>
            <span class="badge bg-danger ms-2 fs-6"><?= $alertas_inv ?> alerta(s) de stock</span>
        <?php endif; ?>
    </h4>
    <!-- No hay "Nuevo" porque el inventario se genera automáticamente con los ingresos -->
    <span class="text-muted small">
        <i class="bi bi-info-circle me-1"></i>
        El stock sube automáticamente al registrar compras.
    </span>
</div>

<!-- Leyenda de alertas -->
<div class="alert alert-warning d-flex align-items-center mb-3 py-2" role="alert">
    <i class="bi bi-exclamation-triangle-fill me-2"></i>
    Las filas resaltadas indican productos con stock <strong class="ms-1">igual o por debajo del mínimo</strong>.
    Usa el botón <i class="bi bi-pencil-fill"></i> para ajustar manualmente.
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table id="tablaInventario" class="table table-striped table-bordered align-middle w-100">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Producto</th>
                        <th class="text-center">Stock Actual</th>
                        <th class="text-center">Stock Mínimo</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php echo $data_inventario->vista_tabla(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>#</th>
                        <th>Producto</th>
                        <th class="text-center">Stock Actual</th>
                        <th class="text-center">Stock Mínimo</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<!-- MODAL: AJUSTE MANUAL DE STOCK 
     Permite corregir el stock por merma, pérdida o error de conteo sin pasar por una compra.-->
<div class="modal fade" id="modalInventario" tabindex="-1" aria-labelledby="tituloModalInv">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header modal-header-bakery">
                <h5 class="modal-title" id="tituloModalInv">Ajustar Stock</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <input type="hidden" id="id_inventario" value="0">

                <div class="mb-3">
                    <label class="form-label fw-semibold">Producto</label>
                    <!-- Solo lectura: el nombre no se edita -->
                    <input type="text" class="form-control" id="nombre_producto_inv" readonly>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Stock Actual <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="stock_actual_inv"
                               min="0" step="1" required>
                        <div class="form-text">Ingresa el stock real contado.</div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Stock Mínimo <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="stock_minimo_inv"
                               min="0" step="1" required>
                        <div class="form-text">Alerta cuando el stock llegue a este nivel.</div>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button class="btn btn-bakery" id="btn-guardar-inventario">
                    <i class="bi bi-floppy-fill me-1"></i> Guardar Ajuste
                </button>
            </div>
        </div>
    </div>
</div>
