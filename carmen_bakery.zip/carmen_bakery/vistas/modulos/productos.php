<!-- MÓDULO: PRODUCTOS (CATÁLOGO)
     Vista parcial incluida por panel.php. -->

<div class="d-flex justify-content-between align-items-center mb-3 mt-3">
    <h4 class="mb-0"><i class="bi bi-box-seam-fill me-2 text-warning"></i>Catálogo de Productos</h4>
    <button class="btn btn-bakery" id="btn-nuevo-producto">
        <i class="bi bi-plus-lg me-1"></i> Nuevo Producto
    </button>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table id="tablaProductos" class="table table-striped table-bordered align-middle w-100">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Producto</th>
                        <th>Descripción</th>
                        <th>Precio</th>
                        <th>Categoría</th>
                        <th>Estado</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php echo $data_productos->vista_tabla(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>#</th>
                        <th>Producto</th>
                        <th>Descripción</th>
                        <th>Precio</th>
                        <th>Categoría</th>
                        <th>Estado</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<!-- MODAL: NUEVO / EDITAR PRODUCTO-->
<div class="modal fade" id="modalProducto" tabindex="-1" aria-labelledby="tituloModalProducto">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="modal-header modal-header-bakery">
                <h5 class="modal-title" id="tituloModalProducto">Nuevo Producto</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <input type="hidden" id="id_producto_catalogo" value="0">

                <div class="mb-3">
                    <label class="form-label">Nombre del Producto <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="nombre_producto" maxlength="150" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Descripción</label>
                    <textarea class="form-control" id="descripcion" rows="2" maxlength="255"
                              placeholder="Descripción breve del producto (opcional)"></textarea>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Precio de Venta ($) <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="precio_venta"
                               min="0.01" step="0.01" placeholder="0.00" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Categoría <span class="text-danger">*</span></label>
                        <select class="form-select" id="id_categoria">
                            <?php echo $data_productos->vista_categorias(); ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button class="btn btn-bakery" id="btn-guardar-producto">
                    <i class="bi bi-floppy-fill me-1"></i> Guardar
                </button>
            </div>
        </div>
    </div>
</div>
