<?php
session_start();
if (!isset($_SESSION['id_usuario'])) { header('Location: ../index.php'); exit; }

require_once '../modelos/conexion.php';
require_once '../modelos/usuarios.php';
require_once '../modelos/productos.php';
require_once '../modelos/inventario.php';

$data_usuarios   = new Usuarios();
$data_productos  = new Productos();
$data_inventario = new Inventario();

$rol      = $_SESSION['rol'];
$es_admin = ($rol === 'Administrador');

// ── Módulo por defecto según rol ──────────────────────────────────────────
// El Administrador entra a Usuarios; los demás roles entran a Productos.
// Así el Vendedor/Bodeguero nunca ve el módulo de usuarios por defecto.
$modulo_default = $es_admin ? 'usuarios' : 'productos';
$modulo         = $_GET['modulo'] ?? $modulo_default;

// Seguridad: si un no-admin intenta acceder a 'usuarios' por URL, redirigir
if ($modulo === 'usuarios' && !$es_admin) {
    header('Location: panel.php?modulo=productos');
    exit;
}

$alertas_inv = $data_inventario->contar_alertas();

// Mapa módulo → título e ícono para el topbar
$info_modulo = [
    'usuarios'   => ['titulo' => 'Gestión de Usuarios',  'icono' => 'bi-people-fill'],
    'productos'  => ['titulo' => 'Catálogo de Productos', 'icono' => 'bi-box-seam-fill'],
    'inventario' => ['titulo' => 'Inventario',            'icono' => 'bi-clipboard2-data-fill'],
];
$titulo_modulo = $info_modulo[$modulo]['titulo'] ?? 'Panel';
$icono_modulo  = $info_modulo[$modulo]['icono']  ?? 'bi-grid';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>El Carmen Bakery — <?= htmlspecialchars($titulo_modulo) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/2.0.3/css/dataTables.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
<div class="layout-wrapper">

    <!-- SIDEBAR-->
    <aside class="sidebar">

        <!-- Logo -->
        <div class="sidebar-brand">
            <img src="../assets/logo.png" alt="El Carmen Bakery">
            <span class="brand-name">El Carmen Bakery</span>
        </div>

        <!-- Navegación -->
        <nav class="sidebar-nav">
            <span class="nav-label">Administración</span>

            <?php if ($es_admin): ?>
            <!-- Solo el Administrador ve el módulo de Usuarios -->
            <a href="panel.php?modulo=usuarios"
               class="nav-item <?= $modulo === 'usuarios' ? 'active' : '' ?>">
                <i class="bi bi-people-fill"></i> Usuarios
            </a>
            <?php endif; ?>

            <a href="panel.php?modulo=productos"
               class="nav-item <?= $modulo === 'productos' ? 'active' : '' ?>">
                <i class="bi bi-box-seam-fill"></i> Productos
            </a>

            <a href="panel.php?modulo=inventario"
               class="nav-item <?= $modulo === 'inventario' ? 'active' : '' ?>">
                <i class="bi bi-clipboard2-data-fill"></i> Inventario
                <?php if ($alertas_inv > 0): ?>
                    <span class="badge bg-danger"><?= $alertas_inv ?></span>
                <?php endif; ?>
            </a>

            <span class="nav-label mt-2">Próximamente</span>

            <span class="nav-item disabled">
                <i class="bi bi-cart3"></i> Ventas
            </span>
            <span class="nav-item disabled">
                <i class="bi bi-truck"></i> Compras
            </span>
        </nav>

    </aside>

    <!-- CONTENIDO PRINCIPAL-->
    <div class="main-content">

        <!-- Topbar -->
        <header class="topbar">
            <div>
                <span class="topbar-title">
                    <i class="bi <?= $icono_modulo ?> me-1" style="color:var(--bakery-rosa)"></i>
                    <?= htmlspecialchars($titulo_modulo) ?>
                </span>
                <div class="topbar-sub">El Carmen Bakery &rsaquo; <?= htmlspecialchars($titulo_modulo) ?></div>
            </div>
            <div class="d-flex align-items-center gap-3">
                <span class="text-muted small">
                    <i class="bi bi-person-circle me-1" style="color:var(--bakery-rosa)"></i>
                    <strong><?= htmlspecialchars($_SESSION['nombre']) ?></strong>
                    <span class="badge ms-1" style="background:var(--bakery-cafe);color:#f0d9cc">
                        <?= htmlspecialchars($rol) ?>
                    </span>
                </span>
                <a href="../controladores/logout.php"
                   onclick="return confirm('¿Deseas cerrar sesión?')"
                   class="btn btn-sm btn-outline-danger">
                    <i class="bi bi-box-arrow-right me-1"></i> Salir
                </a>
                <!-- Botón hamburguesa solo en móvil -->
                <button class="btn btn-sm d-md-none" id="btnSidebar"
                        style="background:var(--bakery-crema);border:1px solid #d8c4b8">
                    <i class="bi bi-list fs-5"></i>
                </button>
            </div>
        </header>

        <!-- Área de módulos -->
        <main class="content-area">
            <?php
            switch ($modulo) {
                case 'usuarios':   include 'modulos/usuarios.php';   break;
                case 'productos':  include 'modulos/productos.php';  break;
                case 'inventario': include 'modulos/inventario.php'; break;
                // Default redirige según rol, nunca carga usuarios para no-admin
                default:
                    include $es_admin ? 'modulos/usuarios.php' : 'modulos/productos.php';
                    break;
            }
            ?>
        </main>

        <footer class="main-footer">
            © <span id="anio"></span> El Carmen Bakery — Versión 1.0.0
        </footer>
    </div>

</div>

<!-- Scripts globales -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/2.0.3/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if ($modulo === 'usuarios'):   ?><script src="../js/usuarios.js"></script><?php endif; ?>
<?php if ($modulo === 'productos'):  ?><script src="../js/productos.js"></script><?php endif; ?>
<?php if ($modulo === 'inventario'): ?><script src="../js/inventario.js"></script><?php endif; ?>

<script>
    document.getElementById('anio').textContent = new Date().getFullYear();
    document.getElementById('btnSidebar')?.addEventListener('click', function () {
        document.querySelector('.sidebar').classList.toggle('open');
    });
</script>
</body>
</html>
